package com.intern.ecommerce.payload;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JWTResponse {

    String jwtToken;

    String mobileNumber;

    String role;
}
