package com.intern.ecommerce.service;

import java.util.List;

import com.intern.ecommerce.entity.Cart;
import com.intern.ecommerce.entity.Orders;


public interface OrdersService {
    public Orders getOrdersById(Long orderId) throws Exception;

    public Orders addOrder(Cart cart) throws Exception;

	public List<Orders> allOrders();

    public List<Orders> orderByCustomerCustomerId(Long customerCustomerId);

}
