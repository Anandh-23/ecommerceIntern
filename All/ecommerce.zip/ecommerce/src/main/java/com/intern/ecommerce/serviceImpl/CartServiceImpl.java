package com.intern.ecommerce.serviceImpl;

import com.intern.ecommerce.entity.Cart;
import com.intern.ecommerce.entity.CartProduct;
import com.intern.ecommerce.entity.Customer;
import com.intern.ecommerce.entity.Product;
import com.intern.ecommerce.exception.CartAlreadyExistException;
import com.intern.ecommerce.exception.CartNotFoundException;
//import com.intern.ecommerce.repository.CartProductRepository;
import com.intern.ecommerce.exception.CustomerNotFoundException;
import com.intern.ecommerce.repository.CartRepository;
import com.intern.ecommerce.repository.CustomerRepository;
import com.intern.ecommerce.repository.ProductRepository;
import com.intern.ecommerce.service.CartService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

     @Override
    public Cart getCartById(Long cartId) throws Exception {
        log.info("Fetching cart by Id");
        Cart cartById =  cartRepository.findById(cartId).get();
        if(cartById == null){
            log.info("Cart not present throws Exception");
            throw new CartNotFoundException("Cart Not Found");
        }
        log.info("Cart found");
        return cartById;
    }

    @Override
    public Cart addToCart(Cart cart) throws Exception {
        log.info("Fetching customer by customerId taken from cart object");
        Optional<Customer> customer = customerRepository.findById(cart.getCustomer().getCustomerId());
        Optional<Cart> cart1 = cartRepository.findByCustomerCustomerId(cart.getCustomer().getCustomerId());
        if (cart1.isPresent()){
            throw new CartAlreadyExistException("Cart already exists for this customer");
        }
        cart.setCustomer((customer.get()));
        log.info("Adding cartProducts to database");
        List<CartProduct> cartProductList = cart.getCartProducts();
        for(CartProduct cartProduct : cartProductList)
        {
            Optional<Product> product = productRepository.findById((cartProduct.getProduct().getProductId()));
            cartProduct.setProduct(product.get());
            log.info("Calculating Price");
            cartProduct.setAmount(product.get().getPrice() * cartProduct.getQuantity());
        }

        return cartRepository.save(cart);

    }

    @Override
    public Cart updateCart(Long cartId, Cart cart) {
        Optional<Cart> optionalCart = cartRepository.findById(cartId);
        Cart oldCart = optionalCart.get();
        log.info("Removing cartProducts");
        oldCart.getCartProducts().clear();
        log.info("Adding cartProducts to cartProduct table");
        oldCart.getCartProducts().addAll(cart.getCartProducts());
        List<CartProduct> cartProductList = oldCart.getCartProducts();
        for(CartProduct cartProduct : cartProductList){
            Optional<Product> product = productRepository.findById((cartProduct.getProduct().getProductId()));
            cartProduct.setProduct(product.get());
            log.info("Calculating Price");
            cartProduct.setAmount(product.get().getPrice() * cartProduct.getQuantity());
        }
        return cartRepository.save(oldCart);
    }

    @Override
    public String deleteCart(Long cartId) {
        cartRepository.deleteById(cartId);
        return "Deleted successfully";
    }

    @Override
    public String deleteCartByCustomerCustomerId(Long customerId) {
        Cart cart = cartRepository.findByCustomerCustomerId(customerId).get();
        cartRepository.deleteById(cart.getCartId());
        return "Deleted Successfully";
    }

    @Override
    public Cart getCartByCustomerId(Long customerId) throws Exception  {
        Optional<Cart> cartByCustomerId = cartRepository.findByCustomerCustomerId(customerId);
        if(!cartByCustomerId.isPresent())
            throw new CartNotFoundException("Cart Not Found");
        return cartByCustomerId.get();
    }
}
