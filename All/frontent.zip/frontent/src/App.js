import { Route, Routes, Navigate } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AuthForm from "./components/Authentication/AuthForm";
import Layout from "./components/Layout/Layout";
import ViewProduct from "./components/Product/ViewProduct";
import Cart from "./components/Cart/Cart";
import CartProvider from "./components/Service/CartContext";
import UserContextProvider from "./components/Service/UserContext";
import Dashboard from "./components/Admin/Dashboard";
import Orders from "./components/Admin/Orders";
import UserOrders from "./components/Order/UserOrders";
import Balance from "./components/Order/Balance";
import Logout from "./components/Logout";

function App() {

  return (
    <UserContextProvider>
      <CartProvider>
      <ToastContainer />
        <div>
          <Layout>
            <Routes>
              <Route path="/" exact element={<ViewProduct />} />
              <Route path="/auth" element={<AuthForm />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/admin" element={<Dashboard />} />
              <Route path="/adminOrders" element={<Orders />} />
              <Route path="/userOrders" element={<UserOrders />} />
              <Route path="/balance" element={<Balance />} />
              <Route path="/logout" element={<Logout />} />
              <Route path="*" element={<Navigate replace to="/" />} />
            </Routes>
          </Layout>
        </div>
      </CartProvider>
    </UserContextProvider>
  );
}

export default App;
