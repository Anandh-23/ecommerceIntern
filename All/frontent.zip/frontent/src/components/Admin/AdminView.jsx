const AdminView = ({productsList,handleEdit,handleDelete}) => {
    return(
        <div>
            {productsList.length > 0 ? <table className='table table-striped table-hover table-responsive' style={{marginTop:'4.5rem',marginLeft:'22.5rem'}}>
                <thead>
                    <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Product</th>
                        <th scope="col">Price </th>
                        <th scope="col">Stock</th>
                        <th scope="col">Category</th>
                        <th scope="col" style={{textAlign:'center'}}>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        
                        (productsList.map((product,i) => (
                            <tr key ={product.productId}>
                                <td>{i+1}</td>
                                <td>{product.productName}</td>
                                <td>{product.price}</td>
                                <td>{product.stock}</td>
                                <td>{product.category}</td>
                                <td>
                                    <div style={{display: 'flex'}}>
                                        <button className="btn btn-primary mr-2" onClick={()=> handleEdit(product.productId)}>Edit</button>
                                        <button className="btn btn-danger" onClick={()=> handleDelete(product.productId)}>Delete</button>
                                    </div>
                                </td>
                            </tr>
                        ))) 
                    }
                </tbody>
            </table>: (<b style={{marginTop: "5rem"}}>Add products</b>)}
        </div>
    )
}

export default AdminView;