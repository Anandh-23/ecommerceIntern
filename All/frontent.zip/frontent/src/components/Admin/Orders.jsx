import { useState, useEffect } from "react";

const Orders = () => {
  const token = localStorage.getItem("jwtToken");
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
            "http://localhost:8080/allOrders",{
              headers:{
                'Authorization' : `Bearer ${token}`
            },
            }
          );
        const jsonData = await response.json();
        setOrders(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [token]);

  return (
    <center>{orders.length > 0 ?
      <table
        className="table table-striped table-hover"
        style={{ marginTop: "4.5rem",width:"40%"}}
      >
        <thead>
          <tr>
            <th scope="col">Order No.</th>
            <th scope="col">Customer Id</th>
            <th scope="col">Date </th>
            <th scope="col">Worth</th>
          </tr>
        </thead>
        <tbody>
          {(
            orders.map((order, i) => (
              <tr key={order.ordersId}>
                <td>{i + 1}</td>
                <td>{order.customer.customerId}</td>
                <td>{order.date}</td>
                <td>{order.totalAmount}</td>
              </tr>
            ))
          )}
        </tbody>
      </table> : <b>No Orders</b>}
    </center>
  );
};

export default Orders;
