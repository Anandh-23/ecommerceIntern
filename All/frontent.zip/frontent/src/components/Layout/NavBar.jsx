import {Navbar,Nav, Container} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';
import { Cart4 } from 'react-bootstrap-icons';
import {useUser, UserContext } from '../Service/UserContext';
import { Link } from 'react-router-dom';

const NavBar = () => {
    const {isLoggedin,user,setIsLoggedin,setUser} = useUser(UserContext);

    const isCustomer = user === "ROLE_CUSTOMER";
    const isAdmin = user ==="ROLE_ADMIN";

    const logoutHandler = () => {
        localStorage.removeItem("customerId");
        localStorage.removeItem("dbrole");
        localStorage.removeItem("jwtToken");
        localStorage.removeItem("cartData");
        setIsLoggedin(false);
        setUser("ROLE_GUEST");

    }

    return(
    <div>
        <Navbar variant='dark' style={{background: '#024180'}} fixed='top'>
            <Container>
                <Link to= "/">
                <Navbar.Brand style={{color: 'rgb(248, 248, 96)',fontSize: '30px',fontFamily:'DM Sans'}}><Cart4 /> E-Commerce </Navbar.Brand>
                </Link>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto" style={{fontFamily:'Poppins'}}>
                    {!isLoggedin && <LinkContainer to="/auth">
                        {<Nav.Link>Login</Nav.Link>}
                    </LinkContainer>}

                    {<LinkContainer to="/">
                        {<Nav.Link>Home</Nav.Link>}
                    </LinkContainer>}

                    {isCustomer && <LinkContainer to="/cart">
                        {<Nav.Link>Cart</Nav.Link>}
                    </LinkContainer>}

                    {isAdmin && <LinkContainer to="/admin">
                        {<Nav.Link>Admin</Nav.Link>}
                    </LinkContainer>}

                    {isAdmin && <LinkContainer to="/adminOrders">
                        {<Nav.Link>Orders</Nav.Link>}
                    </LinkContainer>}

                    {isCustomer && <LinkContainer to="/userOrders">
                        {<Nav.Link>My Order</Nav.Link>}
                    </LinkContainer>}

                    {isCustomer && <LinkContainer to="/balance">
                        {<Nav.Link>Balance</Nav.Link>}
                    </LinkContainer>}

                    {isLoggedin && <LinkContainer to="/logout">
                        {<Nav.Link onClick={logoutHandler}>Logout</Nav.Link>}
                    </LinkContainer>}
                </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    </div>
    )
}

export default NavBar;