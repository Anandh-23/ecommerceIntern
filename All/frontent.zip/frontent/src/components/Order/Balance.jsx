import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';

const Balance = () => {
  const custId = localStorage.getItem("customerId");
  const [balance, setBalance] = useState(0);
  const token = localStorage.getItem("jwtToken");

  useEffect(() => {
      const fetchData = async () => {
          try {
            const response = await fetch(
              `http://localhost:8080/user/showBalance/${custId}`,{
                headers:{
                  'Authorization' : `Bearer ${token}`
              },
              }
            );
          const jsonData = await response.json();
          setBalance(jsonData);
          } catch (error) {
          console.error('Error fetching data:', error);
          }
      };
  
      fetchData();
      }, [custId, token]);
  
  const [showInputBox, setShowInputBox] = useState(false);
  const [amount, setAmount] = useState('');

  const handleAddBalance = () => {
    setShowInputBox(true);
  };

  const handleInputChange = (event) => {
    setAmount(event.target.value);
  };

  const handleConfirm = async() => {
    setBalance((prevBalance) => prevBalance + parseFloat(amount));
    setShowInputBox(false);

    const addBalance =  await fetch(
      `http://localhost:8080/user/addBalance/${custId}?topUp=${amount}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          'Authorization' : `Bearer ${token}`
        },
      }
    );

    if (addBalance.ok) {
      toast.success("Balance Updated Successfully");
    } else {
      console.log("Update Balance error");
    }    
    setAmount('');

  };

  return (
    <div className="container" style={{marginTop : "7rem"}}>
      <div className="card mt-5">
        <div className="card-body">
          <h5 className="card-title">Balance</h5>
          <p className="card-text">Balance: {balance}</p>
          {!showInputBox && (
            <button className="btn btn-primary" onClick={handleAddBalance}>
              Add Balance
            </button>
          )}
          {showInputBox && (
            <div>
              <input
                type="text"
                className="form-control mt-3"
                placeholder="Enter amount"
                value={amount}
                onChange={handleInputChange}
              />
              <button className="btn btn-primary mt-2" onClick={handleConfirm}>
                Confirm
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Balance;
