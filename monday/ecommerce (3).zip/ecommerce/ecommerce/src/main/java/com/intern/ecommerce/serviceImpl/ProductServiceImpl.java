package com.intern.ecommerce.serviceImpl;

import com.intern.ecommerce.entity.Product;
import com.intern.ecommerce.exception.ProductNotCreatedException;
import com.intern.ecommerce.exception.ProductNotFoundException;
import com.intern.ecommerce.repository.ProductRepository;
import com.intern.ecommerce.service.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
public class ProductServiceImpl implements ProductService {
	
    @Autowired
    private ProductRepository productRepository;
    
    @Override
    public Product saveProduct(Product product) throws ProductNotCreatedException {
        Product savedProduct;
        try{
            log.info("Saving product");
            savedProduct =  productRepository.save(product);
        }

        catch (Exception e) {
            log.info("Exception occurs");
            throw new ProductNotCreatedException("Product Not Created");
        }
        return savedProduct;
    }

    @Override
    public List<Product> allProducts() {
        log.info("Fetching products");
        return productRepository.findAll();
    }

    @Override
    public Product findProductById(Long productId) throws ProductNotFoundException {
        log.info("Fetching products by Id");
        Optional<Product> product = productRepository.findById(productId);
        if(!product.isPresent()){
            throw new ProductNotFoundException("Product Not Available");
        }
        return product.get();
    }

    @Override
    public Product updateProduct(Long productId, Product product) {
        log.info("Fetching products by Id");
        Product updateproduct = productRepository.findById(productId).get();
        if(Objects.nonNull(product.getProductName()) && !"".equalsIgnoreCase(product.getProductName())){
            updateproduct.setProductName(product.getProductName());
        }
        if(Objects.nonNull(product.getStock())){
            updateproduct.setStock(product.getStock());
        }
        if(Objects.nonNull(product.getPrice())){
            updateproduct.setPrice(product.getPrice());
        }
        if(Objects.nonNull(product.getCategory()) && !"".equalsIgnoreCase(product.getCategory())){
            updateproduct.setCategory(product.getCategory());
        }
        return productRepository.save(updateproduct);
    }

    @Override
    public void deleteProductById(Long productId) {
        log.info("Deleting products by Id");
        productRepository.deleteById(productId);
    }

    @Override
    public List<Product> getProductByCategory(String category) {
        log.info("Fetching products by Category");
        return productRepository.findAllByCategoryIgnoreCase(category);
    }

    @Override
    public List<Product> getProductByPrice(Double price) {
        log.info("Fetching products by Price");
        return productRepository.findAllByPrice(price);
    }
}
