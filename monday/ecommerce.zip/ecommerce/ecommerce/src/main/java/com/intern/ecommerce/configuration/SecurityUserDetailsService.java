package com.intern.ecommerce.configuration;

import com.intern.ecommerce.entity.Customer;
import com.intern.ecommerce.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class SecurityUserDetailsService implements UserDetailsService {

    @Autowired
    private CustomerRepository customerRepository;
    @Override
    public UserDetails loadUserByUsername(String mobileNumber) throws UsernameNotFoundException {
        Customer customer = customerRepository.findByMobileNumber(mobileNumber);
        if(customer == null)
            throw new UsernameNotFoundException("User with mobile Number not exists");
        return new CustomerDetails(customer);
    }
}
