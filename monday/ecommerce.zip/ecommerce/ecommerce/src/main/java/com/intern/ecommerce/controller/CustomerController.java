package com.intern.ecommerce.controller;

import com.intern.ecommerce.configuration.CustomerDetails;
import com.intern.ecommerce.configuration.JWTHelper;
import com.intern.ecommerce.entity.Customer;
import com.intern.ecommerce.entity.Login;
import com.intern.ecommerce.payload.JWTRequest;
import com.intern.ecommerce.payload.JWTResponse;
import com.intern.ecommerce.service.CustomerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;


@CrossOrigin
@RestController
@RequestMapping("user")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JWTHelper jwtHelper;

    private final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @PostMapping("/addCustomer")
    public Customer saveCustomer(@RequestBody @Valid Customer customer) throws Exception {
        LOGGER.info("Adding Customer");
        return customerService.saveCustomer(customer);
    }

    @PostMapping("/login")
    public ResponseEntity<Object> login(HttpServletRequest request, HttpServletResponse response, @RequestBody @Valid JWTRequest jwtRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(jwtRequest.getMobileNumber(), jwtRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        CustomerDetails userDetails = (CustomerDetails) authentication.getPrincipal();
        String token = jwtHelper.generateToken(userDetails);


        List<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());

        JWTResponse jwtResponse = JWTResponse.builder()
                .jwtToken(token)
                .mobileNumber(userDetails.getUsername())
                .role(roles.get(0)).build();
        return new ResponseEntity<>(jwtResponse, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping
    public List<Customer> allCustomers(){
        LOGGER.info("Fetching Customers");
        return customerService.allCustomers();
    }

    @GetMapping("{customerId}")
    public Customer getCustomerById(@PathVariable("customerId") Long customerId) throws Exception {
        LOGGER.info("Fetching Customers by CustomerId");
        return customerService.getCustomerById(customerId);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @GetMapping("/showBalance/{customerId}")
    public Double getBalanceById(@PathVariable("customerId") Long customerId){
        LOGGER.info("Fetching Balance by CustomerId");
        return customerService.getBalanceById(customerId);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @PutMapping("/addBalance/{customerId}")
    public Double addBalanceById(@PathVariable("customerId") Long customerId,@RequestParam("topUp") Double topUp){
        LOGGER.info("Adding Balance by CustomerId");
        return customerService.addBalanceById(customerId,topUp);

    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @PutMapping("{customerId}")
    public Customer updateCustomer(@PathVariable("customerId")Long customerId,@RequestBody @Valid Customer customer){
        LOGGER.info("Updating customer by CustomerId");
        return customerService.updateCustomer(customerId,customer);
    }

    @DeleteMapping("{customerId}")
    public void deleteCustomer(@PathVariable("customerId")Long customerId){
        LOGGER.info("Deleting customer by CustomerId");
        customerService.deleteCustomer(customerId);
    }

}
