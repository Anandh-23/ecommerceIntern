package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Product;
import com.intern.ecommerce.service.ProductService;

import jakarta.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Slf4j
@RestController
public class ProductController {
	
    @Autowired
    private ProductService productService;

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @PostMapping("/addProduct")
    public Product saveProduct(@RequestBody @Valid Product product) throws Exception {
        log.info("Adding Product");
        return productService.saveProduct(product);
    }

    @GetMapping("/getAllProducts")
    public List<Product> allProducts(){
        log.info("Fetching Product");
        return productService.allProducts();
    }

    @GetMapping("/products/{id}")
    public Product findProductById(@PathVariable("id") Long productId) throws Exception {
        log.info("Fetching Product");
        return productService.findProductById(productId);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable("id") Long productId,@RequestBody @Valid Product product){
        log.info("Updating Product");
        return productService.updateProduct(productId,product);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @DeleteMapping("/products/{id}")
    public String deleteProductById(@PathVariable("id")Long productId){
        productService.deleteProductById(productId);
        log.info("Product Deleted");
        return "Deleted";
    }

    @GetMapping("/products/category/{category}")
    public List<Product> getProductByCategory(@PathVariable("category") String category){
        log.info("Fetching product by category");
        return productService.getProductByCategory(category);
    }

    @GetMapping("/products/price/{price}")
    public List<Product> getProductByPrice(@PathVariable("price") Double price){
        log.info("Fetching product by price");
        return productService.getProductByPrice(price);
    }
}
