package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Cart;
import com.intern.ecommerce.service.CartService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@Slf4j
@RestController
@RequestMapping("/cart")
public class CartController {
	
    @Autowired
    private CartService cartService;

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @GetMapping("/{cartId}")
    public Cart getCartById(@PathVariable("cartId") Long cartId) throws Exception {
        log.info("Fetching cart by Id");
        return cartService.getCartById(cartId);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Cart> getCartByCustomerId(@PathVariable("customerId") Long customerCustomerId) throws Exception {
        Cart cart = cartService.getCartByCustomerId(customerCustomerId);
        if(cart == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        return ResponseEntity.ok(cart);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @PostMapping("/addToCart")
    public Cart addToCart(@Valid @RequestBody Cart cart) throws Exception {
        log.info("Adding cart to database");
        return cartService.addToCart(cart);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @PutMapping("/updateCart/{cartId}")
    public Cart updateCart(@PathVariable("cartId") Long cartId,@Valid @RequestBody Cart cart) throws Exception {
        log.info("Updating cart by Id");
        return cartService.updateCart(cartId, cart);
    }

    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    @DeleteMapping("/deleteCart/{cartId}")
    public String deleteCart(@PathVariable("cartId") Long cartId){
        log.info("Deleting cart by Id");
        cartService.deleteCart(cartId);
        return "Cart Deleted";
    }
}
