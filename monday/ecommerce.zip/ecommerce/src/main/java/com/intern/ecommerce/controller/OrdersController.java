package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Cart;
import com.intern.ecommerce.entity.Orders;
import com.intern.ecommerce.service.CartService;
import com.intern.ecommerce.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
public class OrdersController {
	
    @Autowired
    private OrdersService ordersService;

    @Autowired
    private CartService cartService;

    @GetMapping("/allOrders")
    public List<Orders> allCustomers(){
        return ordersService.allOrders();
    }
    
    @GetMapping("/getOrderById/{orderId}")
    public Orders getOrderById(@PathVariable Long orderId) throws Exception {
        return ordersService.getOrdersById(orderId);
    }

    //Changr
    @PostMapping("/addOrder")
    public ResponseEntity<Orders> addOrder(@RequestBody Cart cart) throws Exception {
        Optional<Cart> savedCart = cartService.getCartByCustomerId(cart.getCustomer().getCustomerId());
        Orders savedOrder;
        if (savedCart.isPresent()){
            savedOrder = ordersService.addOrder(savedCart.get());
        } 
        else{
            savedOrder = ordersService.addOrder(cartService.addToCart(cart));
        }
        cartService.deleteCartByCustomerCustomerId(savedOrder.getCustomer().getCustomerId());
        return ResponseEntity.ok(savedOrder);
    }
    
}
