import { useEffect, useState, useRef} from "react";
import './Add.css';
import { toast } from 'react-toastify';


const Add = ({setAdd,add}) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState(0);
    const [stock, setStock] = useState(0);
    const [category, setCategory] = useState('');
    const [url, setUrl] = useState('');
    const input = useRef(null);

    useEffect(()=>{
        input.current.focus();
    }, [add]);

    const handleAdd = async(event) => {
        event.preventDefault();
        if(name.length < 5 || name.length > 20)
            toast.info("Name should be between 6 to 20");
        if(category.length === 0)
            toast.info("Category can't be null"); 
        if(price === 0)   
            toast.info("Make sure to add the price");
        if(stock === 0)
            toast.info("Make sure to add the stocks");
        let newProduct = {
            'productName':name,
            'price': price,
            'stock': stock,
            'category' : category,
            'url' : url
        }
        console.log(newProduct)

        try{
            const response = await fetch("http://localhost:8080/addProduct",{
                method: 'POST',
                headers:{
                    'Content-Type': 'application/json'
                },
                body:JSON.stringify(newProduct)
            });

            if(response.ok){
                console.log("Not directing")
                setAdd(false)
            }

            else{
                toast.error("Product Already Exists");
            }
        }
        
        catch (error) {
            console.log("An error occurred while adding the product:", error);
        }
    }


    return (
        <div style={{width:'40%',marginTop:'5rem'}}className="container">
        <form>
            <center><h3>Add Product</h3></center>
            <div>
            <label htmlFor="name">Name</label>
            <input
                id="name"
                type="text"
                ref={input}
                placeholder="Enter name"
                name="name"
                minLength="5"
                maxLength="20"
                required
                onChange={(e) => setName(e.target.value)}
            ></input>
            </div>

            <div>
            <label htmlFor="price">Price</label>
            <input
                id="price"
                type="number"
                placeholder="Enter Price"
                name="price"
                required
                onChange={(e) => setPrice(e.target.value)}
            ></input>
            </div>

            <div>
            <label htmlFor="stock">Stock</label>
            <input
                id="stock"
                type="number"
                placeholder="Enter Stock"
                name="stock"
                min = "1"
                required
                onChange={(e) => setStock(e.target.value)}
            ></input>
            </div>

            <div>
            <label htmlFor="category">Category</label>
            <input
                id="category"
                type="text"
                placeholder="Enter Category"
                name="category"
                required
                onChange={(e) => setCategory(e.target.value)}
            ></input>
            </div>

            <div>
            <label htmlFor="url">URL</label>
            <input
                id="url"
                type="url"
                placeholder="Enter Url"
                name="url"
                required
                onChange={(e) => setUrl(e.target.value)}
            ></input>
            </div>

            <div className="center">
                <button className="btn btn-success" type="submit" onClick={handleAdd}>Add</button>
                <button className="btn btn-danger" type="cancel" onClick={() => setAdd(false)}>Cancel</button>
            </div>
        </form>
        </div>
  );
}

export default Add;