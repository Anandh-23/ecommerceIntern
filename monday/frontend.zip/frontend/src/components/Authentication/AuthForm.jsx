import { useRef,useState } from 'react';
import { useNavigate } from "react-router-dom";
import classes from "./AuthForm.module.css";
import {useUser, UserContext } from '../Service/UserContext';

const AuthForm = () =>{
    const nameRef = useRef();
    const mobileRef = useRef();
    const passwordRef = useRef();
    const [isLogin, setIsLogin] = useState(true);
    const navigate = useNavigate();
    const [customer, setCustomer] = useState();
    let role = "ROLE_CUSTOMER";
    const {setIsLoggedin,setUser} = useUser(UserContext);

    const switchAuthModeHandler = () => {
        setIsLogin((prevState)=>!prevState);
    }

    const submitHandler = async(e)=>{
        e.preventDefault();
        console.log("Submitted");

        const mobileNumber = mobileRef.current.value;
        const password = passwordRef.current.value;
        
        if(nameRef.current.value === "Admin" || nameRef.current.value === "admin"){
            role = "ROLE_ADMIN";
        }
        
        if(!isLogin){
            console.log(customer);
            const response = await fetch("http://localhost:8080/user/addCustomer",{
                method:'POST',
                headers:{
                    'Content-Type':'application/json'
                },
                body:JSON.stringify(customer)
            });

            if(response.ok){
                navigate("/auth");
            }
            else{
                navigate("/auth");
            }
        }
        
        else{
            const response = await fetch("http://localhost:8080/user/login",{
                method:'POST',
                headers:{
                    'Content-Type':'application/json'
                },
                body:JSON.stringify({ mobileNumber, password })
            });
            if(response.ok){
                setIsLoggedin(true);
                setUser(role);
                if(role==="ROLE_ADMIN")
                    navigate("/admin")
                navigate("/");
            }
            else{
                navigate("/auth");
            }
        }
    }

    return(
        <section className={classes.auth}>
            <h2>{isLogin ? "Login" : "Sign Up"}</h2>
            <form onSubmit={submitHandler}>
                <div className={classes.control}>
                    <label htmlFor="name">Name</label>
                    <input type="text" id="name" required ref={nameRef}/>
                </div>
                <div className={classes.control}>
                    <label htmlFor="mobileNumber">Mobile Number</label>
                    <input type="text" id="mobileNumber" required ref={mobileRef}/>
                </div>
                <div className={classes.control}>
                    <label htmlFor="password">Password</label>
                    <input type="text" id="password" required ref={passwordRef}/>
                </div>
                <div className={classes.actions}>
                    <button type="submit" onClick={() => {
                        setCustomer({
                            customerName:nameRef.current.value,
                            mobileNumber:mobileRef.current.value,
                            password:passwordRef.current.value,
                            role:role,
                            balance:100
                        })
                        }}>{isLogin ? "Login" : "Create Account"}</button>
                    <button type="button" className={classes.toggle} style={{outline:"none"}} onClick={switchAuthModeHandler}>{isLogin ? "Create new account" : "Login with existing account"}
                    </button>
                </div>
            </form>
        </section>
    )
}

export default AuthForm;