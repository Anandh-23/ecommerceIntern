import { useState, useEffect } from "react";
import { Card, Button } from "react-bootstrap";
import {useNavigate} from 'react-router-dom';
const Cart = () => {
  const custId = localStorage.getItem("customerId");
  const [cartItems, setCartItems] = useState([]);
  const [cart, setCart] = useState({
    customer: {
      customerId: custId,
    },
    cartProducts: [],
  });

  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const navigate = useNavigate();

  const updateCartItems = (jsonData) => {
    setCartItems(jsonData.cartProducts);
    setCart(jsonData);
    console.log(jsonData.cartProducts);
  };

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/cart/customer/${custId}`
        );
        const jsonData = await response.json();
        console.log(jsonData);
        updateCartItems(jsonData);
      } catch (error) {
        console.error("Error fetching cart:", error);
      }
    };

    fetchCart();
  }, [custId]);

  const incrementHandler = async(cartProductId , quantity ) => {
    const updatedCartItems = cartItems.map((item,index) => {
      if(index === cartProductId){
        return {...item, quantity : quantity + 1, amount : (quantity+1) * item.product.price};
      }
      return item;
    });
    setCartItems(updatedCartItems);

    const newCart = {
      ...cart,
      cartProducts : updatedCartItems
    }

    setCart(newCart);

    console.log("UP",updatedCartItems);
    console.log(cartItems);
  }

  const decrementHandler = (cartProductId , quantity ) => {
    if(quantity <= 1){
      return;
    }

    const updatedCartItems = cartItems.map((item,index) => {
      if(index === cartProductId){
        return {...item, quantity : quantity - 1 , amount : (quantity-1) * item.product.price};
      }
      return item;
    });

    setCartItems(updatedCartItems);

    const newCart = {
      ...cart,
      cartProducts : updatedCartItems
    }

    setCart(newCart);

    console.log(updatedCartItems)
    console.log(cartItems);
  }

  const removeItem = async(cartProductId) => {
    console.log("Id",cartProductId)
    const storedCartItems = cartItems.filter((item) => item.cartProductId !== parseInt(cartProductId,10));
    setCartItems(storedCartItems);
    const newCart = {
      ...cart,
      cartProducts : storedCartItems
    }
    setCart(newCart);
    updateInBackend();
    console.log("NEW CART",newCart);
    console.log("UP Cart",cart);
  }

  const updateInBackend = async() => {
    const cartId = cart.cartId;

    const cartResponse =  await fetch(
      `http://localhost:8080/cart/updateCart/${cartId}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cart),
      }
    );

    if (cartResponse.ok) {
      alert("Updated Successfully");
    } else {
      alert("Update Cart error");
    }
  }

  const addOrder = async() => {
    try{
      const cartResponse =  await fetch(
        "http://localhost:8080/addOrder",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(cart),
        }
      );
  
      if (cartResponse.ok) {
        alert("Placed Successfully");
      } else {
        const errorResponse = await cartResponse.json();
        const errorMessage = errorResponse.message;
        alert(errorMessage);
      }
    }
    catch(error){
      alert("Error",error)
    }
  }

  const placeOrder = async() => {
    setCart(cart);
    await addOrder();
    console.log("Order",cart);
  }

  const goBack = async() => {
    setCart(cart);
    await updateInBackend();
    navigate("/")
  }


  return (
    <div className = "d-flex justify-content-center align-items-center" style={{minHeight : "100vh"}}>
      <div className = "mx-auto">
        <div style={{ marginTop: "8rem"}} className="container">
        {Array.isArray(cartItems) && cartItems.length > 0 ? (
          <center>
              {cartItems.map((item,index) => (
                <div className="row mb-4"  key={item.cartProductId}>
                  <div className="col-lg-4 col-md-5 col-sm-8 mb-3">
                    <Card style={{height : "200px", width: "450px" , border: "1px solid #c2b9b9", boxShadow: "0 2px 4px rgba(66, 66, 66, 0.1)"}} key={index}>
                      <div className="row no-gutters">
                        <div className="col-md-5">
                          <Card.Img
                            variant="top"
                            src={item.product.url}
                            className= "ml-2 mt-2 mb-1"
                            alt={item.product.productName}
                            style={{ width: "150px", height: "150px"}}
                          />
                          <Card.Text>
                              <span className="mb-2">
                                <button style={{background:"none", border: "none", outline: "none"}} 
                                    onClick = {() => decrementHandler(index, item.quantity)}>
                                  -
                                </button>
                                <b>{item.quantity}</b>
                                <button style={{background:"none", border: "none", outline: "none"}} 
                                    onClick = {() => incrementHandler(index, item.quantity)}>
                                  +
                                </button>
                              </span>
                          </Card.Text>
                        </div>
                        <div className="col-md-7 d-flex flex-column justify-content-between" style ={{marginTop : "1rem"}}>
                          <div>
                            <Card.Title>Name : {item.product.productName}</Card.Title>
                            <p>Price : {item.product.price * item.quantity}</p>
                            <Button variant="danger" onClick = {() => removeItem(item.cartProductId)}>
                              Remove
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              ))}
            <div className="row">
              <div className="col-lg-12 d-flex justify-content-center">
              <Button variant="info" onClick={() => goBack()} className="mr-5">
                  Add More
                </Button>
                <Button variant="success" onClick={() => placeOrder()} className="ml-2">
                  Order Now  (Rs.{totalAmount})
                </Button>
              </div>
            </div>
          </center>
        ) : (
          <b style={{fontSize:"x-large"}}>Empty cart, endless possibilities! Start exploring now.</b>
        )}
        </div>
      </div>
    </div>
  );
};

export default Cart;