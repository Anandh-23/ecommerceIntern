const Orders = () => {
    return <h1 style={{marginTop: "5rem"}}>Admin Orders</h1>
}

export default Orders;