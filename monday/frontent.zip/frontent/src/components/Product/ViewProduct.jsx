import { useEffect,useState } from 'react';
import {Card,Button} from 'react-bootstrap';
import { useCart,CartContext } from '../Service/CartContext';
import {useUser, UserContext } from '../Service/UserContext';
function ViewProduct(){

    const {isLoggedin} = useUser(UserContext);

    const [productsData,setProdctsData] = useState([]);
    const {addToCart} = useCart(CartContext);

    useEffect(() => {
        const fetchData = async () => {
            try {
            const response = await fetch('http://localhost:8080/getAllProducts');
            const jsonData = await response.json();
            setProdctsData(jsonData);
            } catch (error) {
            console.error('Error fetching data:', error);
            }
        };
    
        fetchData();
        }, []);

    console.log(productsData);

    const handleAddToCart = (product) => {
        console.log(product);
        addToCart(product);
    }

    return(
        <div className="container" style={{marginTop:'5rem'}}>
            <h1 style={{textAlign:'center'}}>List of Products</h1>
            <div className="row" >
                {productsData.map((product)=>(
                    <div key = {product.productId} className="col-md-3" style={{marginTop:'1rem'}}>
                        <Card style={{ width: '15rem',alignItems:'center'}}>
                            <Card.Img variant="top" src={product.url} alt={product.name} style={{width:'9rem', height:'9rem',marginTop:'1rem'}}></Card.Img>
                            <Card.Body>
                                <Card.Title>Name : {product.productName}</Card.Title>
                                <Card.Text>Category : {product.category}</Card.Text>
                                <Card.Text>Price : Rs.{product.price}</Card.Text>
                                {isLoggedin && <Button variant="info" onClick={()=>handleAddToCart(product)}>Add to Cart</Button>}
                            </Card.Body>
                        </Card>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default ViewProduct;
