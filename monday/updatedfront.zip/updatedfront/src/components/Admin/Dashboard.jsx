import Add from "./Add";
import AdminView from "./AdminView";
import { useEffect, useState } from "react";
import Edit from "./Edit";
import { CardList } from "react-bootstrap-icons";
import { toast } from "react-toastify";
const token = localStorage.getItem("jwtToken")

function Dashboard() {
  const [productsData, setProductsData] = useState([]);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [deleteData, setDeleteData] = useState(false);
  const [add, setAdd] = useState(false);
  const [edit, setEdit] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8080/getAllProducts");
        const jsonData = await response.json();
        setProductsData(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [add, edit, deleteData]);

  const handleEdit = (id) => {
    const [products] = productsData.filter(
      (products) => products.productId === id
    );
    setSelectedProduct(products);
    setEdit(true);
  };

  const handleDelete = async(id) => {
    try{
      const response = await fetch(`http://localhost:8080/products/${id}`,{
        method: 'DELETE',
        headers:{
          'Authorization' : `Bearer ${token}`
        },
      })
      if(response.ok){
        toast.success("Deleted Successfully")
        setDeleteData(true);
      }
      else
        toast.info("Warning!!! It's in Customer's cart")
    }
    catch(e){
      console.log("Unable to Delete",e)
    }
    
  };

  return (
    <>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {!add && !edit && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginLeft: "-15rem",
            }}
          >
            <AdminView
              productsList={productsData}
              handleEdit={handleEdit}
              handleDelete={handleDelete}
            />
            <div style={{ marginLeft: "6rem",marginTop:"2rem"}}>
              <CardList
                size={50}
                style= {{color: "green"}}
                onClick={() => setAdd(true)}
              />
            </div>
          </div>
        )}
        {add && (
          <Add 
            add={add}
            setAdd={setAdd}
          />
        )}
        {edit && (
          <Edit
            selectedProduct={selectedProduct}
            setEdit={setEdit}
            edit = {edit}
          />
        )}
      </div>
    </>
  );
}

export default Dashboard;
