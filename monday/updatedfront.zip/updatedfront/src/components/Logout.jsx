function Logout(){
    return(
        <center style={{marginTop:"14rem"}}>
            <img src="./logout.png" alt="Logged Out"></img>
            <h1>See you soon!!!!</h1>
        </center>
    )
}

export default Logout;