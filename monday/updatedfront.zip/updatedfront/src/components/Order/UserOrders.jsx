import { useState, useEffect } from "react";

function UserOrders() {
  const token = localStorage.getItem("jwtToken");
  const [orders, setOrders] = useState([]);
  const custId = localStorage.getItem("customerId");
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
            `http://localhost:8080/orders/${custId}`,{
              headers:{
                'Authorization' : `Bearer ${token}`
            },
            }
          );
        const jsonData = await response.json();
        setOrders(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [token, custId]);

  return(
    <center>{orders.length > 0 ?
        <table
          className="table table-striped table-hover"
          style={{ marginTop: "4.5rem",width:"40%"}}
        >
          <thead>
            <tr>
              <th scope="col">Order No.</th>
              <th scope="col">Date </th>
              <th scope="col">Worth</th>
            </tr>
          </thead>
          <tbody>
            {(
              orders.map((order, i) => (
                <tr key={order.ordersId}>
                  <td>{i + 1}</td>
                  <td>{order.date}</td>
                  <td>{order.totalAmount}</td>
                </tr>
              ))
            )}
          </tbody>
        </table> : <b>No Orders</b>}
      </center>
  )
}

export default UserOrders;
