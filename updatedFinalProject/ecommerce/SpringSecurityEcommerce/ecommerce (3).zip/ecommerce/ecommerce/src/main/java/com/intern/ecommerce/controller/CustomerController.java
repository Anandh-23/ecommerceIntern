package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Customer;
import com.intern.ecommerce.service.CustomerService;

import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    private final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @PostMapping("/addCustomer")
    public Customer saveCustomer(@RequestBody @Valid Customer customer) throws Exception {
        LOGGER.info("Adding Customer");
        return customerService.saveCustomer(customer);
    }

    @PreAuthorize("hasRole('Admin')")
    @GetMapping
    public List<Customer> allCustomers(){
        LOGGER.info("Fetching Customers");
        return customerService.allCustomers();
    }

    @GetMapping("{customerId}")
    public Customer getCustomerById(@PathVariable("customerId") Long customerId) throws Exception {
        LOGGER.info("Fetching Customers by CustomerId");
        return customerService.getCustomerById(customerId);
    }

    @PreAuthorize("hasRole('Customer')")
    @GetMapping("/showBalance/{customerId}")
    public Double getBalanceById(@PathVariable("customerId") Long customerId){
        LOGGER.info("Fetching Balance by CustomerId");
        return customerService.getBalanceById(customerId);
    }

    @PreAuthorize("hasRole('Customer')")
    @PutMapping("/addBalance/{customerId}")
    public Double addBalanceById(@PathVariable("customerId") Long customerId,@RequestParam("topUp") Double topUp){
        LOGGER.info("Adding Balance by CustomerId");
        return customerService.addBalanceById(customerId,topUp);

    }

    @PreAuthorize("hasRole('Customer')")
    @PutMapping("{customerId}")
    public Customer updateCustomer(@PathVariable("customerId")Long customerId,@RequestBody @Valid Customer customer){
        LOGGER.info("Updating customer by CustomerId");
        return customerService.updateCustomer(customerId,customer);
    }

    @DeleteMapping("{customerId}")
    public void deleteCustomer(@PathVariable("customerId")Long customerId){
        LOGGER.info("Deleting customer by CustomerId");
        customerService.deleteCustomer(customerId);
    }

}
