package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Cart;
import com.intern.ecommerce.entity.Orders;
import com.intern.ecommerce.service.CartService;
import com.intern.ecommerce.service.OrdersService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
public class OrdersController {
	
    @Autowired
    private OrdersService ordersService;

    @Autowired
    private CartService cartService;

    @PreAuthorize("hasRole('Admin')")
    @GetMapping("/allOrders")
    public List<Orders> allOrders(){
        log.info("Fetching orders");
        return ordersService.allOrders();
    }

    @PreAuthorize("hasRole('Customer')")
    @GetMapping("/getOrderById/{orderId}")
    public Orders getOrderById(@PathVariable Long orderId) throws Exception {
        log.info("Fetching order by Id");
        return ordersService.getOrdersById(orderId);
    }

    @PreAuthorize("hasRole('Customer')")
    @PostMapping("/addOrder")
    public Orders addOrder(@RequestBody Cart cart) throws Exception {
        log.info("Verifies order");
        Optional<Cart> savedCart = cartService.getCartByCustomerId(cart.getCustomer().getCustomerId());
        Orders savedOrder;
        if (savedCart.isPresent()){
            log.info("Adding orders to Database");
            savedOrder = ordersService.addOrder(savedCart.get());
        } 
        else{
            log.info("If cart is not stored, store that cart and convert to order");
            savedOrder = ordersService.addOrder(cartService.addToCart(cart));
        }
        log.info("Converting cart to order");
        cartService.deleteCartByCustomerCustomerId(savedOrder.getCustomer().getCustomerId());
        return savedOrder;
    }
    
}
