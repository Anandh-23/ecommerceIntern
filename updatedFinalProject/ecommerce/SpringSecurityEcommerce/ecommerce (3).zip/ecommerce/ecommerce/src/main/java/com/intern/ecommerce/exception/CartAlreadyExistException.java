package com.intern.ecommerce.exception;

public class CartAlreadyExistException extends Exception{
    public CartAlreadyExistException(String message) {
        super(message);
    }
}
