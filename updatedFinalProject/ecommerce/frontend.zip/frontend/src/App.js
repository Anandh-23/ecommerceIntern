import { Route,Routes,Navigate} from "react-router-dom";
import AuthForm from "./components/Authentication/AuthForm";
import Layout from "./components/Layout/Layout";
import ViewProduct from "./components/Product/ViewProduct";

function App() {
  return (
    <div>
        <Layout>
          <Routes>
            <Route  path="/" element={<ViewProduct/>}/>
            <Route  path="/auth" element={<AuthForm/>}/>
            <Route path='*' element={<Navigate replace to="/" />}/>
          </Routes>
        </Layout>
    </div>
  );
}

export default App;
