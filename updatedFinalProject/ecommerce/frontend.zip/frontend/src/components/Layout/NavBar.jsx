import './NavBar.css';
const NavBar = () => {
    return(
    <header className='header'>
        <div className='logo'>E-Commerce</div>

        <nav>
            <ul>
                <li>Login</li>
            </ul>
            <ul>
                <li>Cart</li>
            </ul>
            <ul>
                <li>
                    <button>Log out</button>
                </li>
            </ul>
        </nav>
    </header>
    )
}

export default NavBar;