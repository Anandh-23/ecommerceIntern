import {Card,Button} from 'react-bootstrap';
function ViewProduct(){
    const productsData = [
        {
            id:1,
            name:"Product 1",
            price:1000,
            image:'https://tse1.mm.bing.net/th/id/OIP.tpNo891Vq8MNTLS6DOtzHQHaHa?w=171&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'
        },
        {
            id:2,
            name:"Product 1",
            price:1000,
            image:'https://via.placeholder.com/150'
        },
        {
            id:3,
            name:"Product 1",
            price:1000,
            image:'https://via.placeholder.com/150'
        }
    ]
    return(
        <div className="container">
            <div className="row">
                {productsData.map((product)=>(
                    <div key = {product.id} className="col-md-4">
                        <Card>
                            <Card.Img variant="top" src="https://tse1.mm.bing.net/th/id/OIP.tpNo891Vq8MNTLS6DOtzHQHaHa?w=171&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7" alt={product.name}></Card.Img>
                            <Card.Body>
                                <Card.Title>{product.name}</Card.Title>
                                <Card.Text>${product.price}</Card.Text>
                                <Button variant="primary">Add to Cart</Button>
                                <Button variant="danger">Remove</Button>
                            </Card.Body>
                        </Card>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default ViewProduct;
