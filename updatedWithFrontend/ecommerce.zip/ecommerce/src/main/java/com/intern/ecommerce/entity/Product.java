package com.intern.ecommerce.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;
    @NotBlank(message = "Add name to continue")
    @Column(unique = true)
    @Size(min=5,max=25, message = "Enter Valid Product Name")
    private String productName;
    @NotNull
    private Double price;
    @NotNull
    private String category;
    private Integer stock;
    private String url;

}
