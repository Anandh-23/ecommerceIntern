package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Cart;
//import com.intern.ecommerce.service.CartProductService;
import com.intern.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/cart")
public class CartController {
	
    @Autowired
    private CartService cartService;


    @GetMapping("/{cartId}")
    public Cart getCartById(@PathVariable("cartId") Long cartId) throws Exception {
        return cartService.getCartById(cartId);
    }
    
    @PostMapping("/addToCart")
    public Cart addToCart(@RequestBody Cart cart){
        return cartService.addToCart(cart);
    }
    
    @PutMapping("/updateCart/{cartId}")
    public Cart updateCart(@PathVariable("cartId") Long cartId,@RequestBody Cart cart) throws Exception {
        return cartService.updateCart(cartId, cart);
    }
    
    @DeleteMapping("/deleteCart/{cartId}")
    public String deleteCart(@PathVariable("cartId") Long cartId){
        cartService.deleteCart(cartId);
        return "Cart Deleted";
    }
}
