package com.intern.ecommerce.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.intern.ecommerce.entity.Product;
import com.intern.ecommerce.repository.ProductRepository;
import com.intern.ecommerce.service.ProductService;

@SpringBootTest
class ProductServiceImplTest {

	@Autowired
    private ProductService productService;

    @MockBean
    private ProductRepository productRepository;
    
	Product product = Product.builder().productId(1L).productName("Mi8").price(18000.00).category("Mobile").stock(10).build();
	Product product1 = Product.builder().productId(2L).productName("Mi10").price(28000.00).category("Mobile").stock(10).build();
	Product product2 = Product.builder().productId(3L).productName("BBuds").price(2800.00).category("Buds").stock(1).build();
    Long productId = 1L;
    
    
    @Test
    void testSaveProduct() throws Exception {
    	when(productRepository.save(product)).thenReturn(product);
    	Product result = productService.saveProduct(product);
    	assertEquals(product, result);
    	verify(productRepository,times(1)).save(product);
    }
    
    @Test
    void testGetAllProducts() {
    	List <Product> productList = Arrays.asList(product,product1,product2);
    	Mockito.when(productRepository.findAll()).thenReturn(productList);
    	List<Product> result = productService.allProducts();
    	assertEquals(productList, result);
    }
    
    @Test
    void testGetProductById() throws Exception {
        Mockito.when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        Product found = productService.findProductById(productId);
        assertEquals(found,product);
    }
    
    @Test
    void testUpdateProduct() {
        Product updatedProduct = new Product();
        updatedProduct.setProductId(productId);
        updatedProduct.setProductName("Mi8");
        updatedProduct.setCategory("Mobiles");
        updatedProduct.setPrice(5000.00);
        updatedProduct.setStock(10);
        Mockito.when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        Mockito.when((productRepository.save(product))).thenReturn(updatedProduct);

        Product result = productService.updateProduct(productId,updatedProduct);
        assertEquals(updatedProduct,result);

    }
    
    @Test
    void testDeleteProduct() {
        Mockito.when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        productService.deleteProductById(productId);
    }
    
    @Test
    void testGetAllProductsByCategory() {
    	List <Product> productList = Arrays.asList(product,product1);
    	Mockito.when(productRepository.findAllByCategoryIgnoreCase("Mobile")).thenReturn(productList);
    	List<Product> result = productService.getProductByCategory("Mobile");
    	assertEquals(productList, result);
    }
    
    
    

	

}
