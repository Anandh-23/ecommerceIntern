package com.intern.ecommerce.controller;

import com.intern.ecommerce.entity.Cart;
//import com.intern.ecommerce.service.CartProductService;
import com.intern.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/cart")
public class CartController {
	
    @Autowired
    private CartService cartService;

    @GetMapping("/{cartId}")
    public Cart getCartById(@PathVariable("cartId") Long cartId) throws Exception {
        return cartService.getCartById(cartId);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Cart> getCartByCustomerId(@PathVariable("customerId") Long customerCustomerId) throws Exception {
        Optional<Cart> cart = cartService.getCartByCustomerId(customerCustomerId);
        if(cart == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        return ResponseEntity.ok(cart.get());
    }
    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/addToCart")
    public Cart addToCart(@RequestBody Cart cart){
        return cartService.addToCart(cart);
    }
    
    @PutMapping("/updateCart/{cartId}")
    public Cart updateCart(@PathVariable("cartId") Long cartId,@RequestBody Cart cart) throws Exception {
        return cartService.updateCart(cartId, cart);
    }
    
    @DeleteMapping("/deleteCart/{cartId}")
    public String deleteCart(@PathVariable("cartId") Long cartId){
        cartService.deleteCart(cartId);
        return "Cart Deleted";
    }
}
