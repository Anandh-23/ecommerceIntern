package com.intern.ecommerce.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;
    @Size(min=5,max=20, message = "Enter Valid Name")
    private String customerName;
    @Column(unique = true)
    @Pattern(regexp = "[0-9]{10}", message = "Invalid mobile number")
    private String mobileNumber;
    private String password;
    
    private String role;
    private Double balance;
}
