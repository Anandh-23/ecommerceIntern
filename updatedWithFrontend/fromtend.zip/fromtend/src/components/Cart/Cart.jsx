import { useState, useEffect } from "react";
import { Card, Button } from "react-bootstrap";

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  localStorage.setItem("customerId", 9);
  const custId = localStorage.getItem("customerId");

  const updateCartItems = (jsonData) => {
    setCartItems(jsonData.cartProducts);
    console.log(jsonData.cartProducts);
  };

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/cart/customer/${custId}`
        );
        const jsonData = await response.json();
        console.log(jsonData);
        updateCartItems(jsonData);
      } catch (error) {
        console.error("Error fetching cart:", error);
      }
    };

    fetchCart();
  }, [custId]);



  return (
    <div  style={{ marginTop: "8rem" }} className="container">
      {Array.isArray(cartItems) && cartItems.length > 0 ? (
        <>
          <div className="row mb-4">
            {cartItems.map((item) => (
              <div className="col-lg-4 col-md-5 col-sm-8 mb-3" key={item.cartProductId}>
                <Card>
                  <div className="row no-gutters">
                    <div className="col-md-4">
                      <Card.Img
                        variant="top"
                        src={item.product.url}
                        alt={item.product.productName}
                        style={{ width: "100%", height: "100%" }}
                      />
                    </div>
                    <div className="col-md-8">
                      <Card.Body>
                        <Card.Title>{item.product.productName}</Card.Title>
                        <Card.Text>
                          Quantity: {' '}
                          <span>
                            <button>
                              -
                            </button>
                            {item.quantity}
                            <button>
                              +
                            </button>
                          </span>
                        </Card.Text>
                        <Button variant="danger">
                          Remove
                        </Button>
                      </Card.Body>
                    </div>
                  </div>
                </Card>
              </div>
            ))}
          </div>
          <div className="row">
            <div className="col-lg-12 d-flex justify-content-center">
              <Button variant="success">
                Order Now {`(Total : ${cartItems[1].quantity})`}
              </Button>
            </div>
          </div>
        </>
      ) : (
        <p>No items in the cart.</p>
      )}
    </div>
  );
};

export default Cart;
