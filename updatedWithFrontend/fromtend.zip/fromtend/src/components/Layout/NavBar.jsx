// import './NavBar.css';
import {Navbar,Nav, Container} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';
import { CartFill } from 'react-bootstrap-icons';
// import {useUser, UserContext } from '../Service/user-context';

const NavBar = () => {
    // const {isLoggedin,user} = useUser(UserContext);
    // isCustomer = user ? "" : "";

    return(
    <div>
        <Navbar variant='dark' style={{background: '#024180'}} fixed='top'>
            <Container>
                <Navbar.Brand style={{color: 'rgb(248, 248, 96)',fontSize: '30px',fontFamily:'DM Sans'}}>E-Commerce</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto" style={{fontFamily:'Poppins'}}>
                    <LinkContainer to="/auth">
                        {<Nav.Link>Login</Nav.Link>}
                    </LinkContainer>

                    <LinkContainer to="/cart">
                        {<Nav.Link><CartFill className="navbar-icon"/>Cart</Nav.Link>}
                    </LinkContainer>

                    <LinkContainer to="/admin">
                        {<Nav.Link>My Orders</Nav.Link>}
                    </LinkContainer>

                    <LinkContainer to="/logout">
                        {<Nav.Link>Logout</Nav.Link>}
                    </LinkContainer>
                </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    </div>
    )
}

export default NavBar;