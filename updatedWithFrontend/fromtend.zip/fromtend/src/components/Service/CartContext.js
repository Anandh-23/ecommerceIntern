import { createContext, useContext, useState } from "react";

export const CartContext = createContext();

const CartProvider = ({ children }) => {
  localStorage.setItem("customerId", 9);
  const custId = localStorage.getItem("customerId");
  const [cart, setCart] = useState({
    customer: {
      customerId: custId,
    },
    cartProducts: [],
  });

  let customerCartId;
  const isCartEmpty = async () => {
    const response = await fetch(
      `http://localhost:8080/cart/customer/${custId}`
    );
    const jsonData = await response.json();
    customerCartId = jsonData.cartId;
    console.log("JSON DATA");
    console.log(jsonData);
    setCart((prevCart) => ({
      ...prevCart,
      cartProducts: jsonData.cartProducts,
    }));
    console.log("CART");
    console.log(cart);
    return jsonData.cartProducts.length === 0;
  };

  const addToCart = async (product) => {
    const emptyCart = await isCartEmpty();
    let updatedCart;
    if (emptyCart) {
      console.log("Empty Cart");

      updatedCart = {
        ...cart,
        cartProducts: [
          {
            product: {
              productId: product.productId,
            },
            quantity: 1,
          },
        ],
      };

      const cartResponse = await fetch("http://localhost:8080/cart/addToCart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedCart),
      });

      if (cartResponse.ok) {
        alert("Added Successfully");
      } else {
        alert("Empty Cart error");
      }
    } 
    
    else {
      const existingProduct = cart.cartProducts.find(
        (cartProduct) => cartProduct.product.productId === product.productId
      );

      if (existingProduct) {
        updatedCart = {
          ...cart,
          cartProducts : cart.cartProducts.map(
            (item) => item.product.productId === product.productId ? 
            {
              ...item,
              quantity: item.quantity + 1,
            } : item
            )
        }
      } 
      
      else {
        updatedCart = {
          ...cart,
          cartProducts: [
            ...cart.cartProducts,
            {
              product: {
                productId: product.productId,
              },
              quantity: 1,
            },
          ],
        };
      }

      const cartResponse = await fetch(
        `http://localhost:8080/cart/updateCart/${customerCartId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedCart),
        }
      );

      if (cartResponse.ok) {
        alert("Updated Successfully");
      } else {
        alert("Update Cart error");
      }
    }
    setCart(updatedCart);
  };

  return (
    <CartContext.Provider value={{ cart, addToCart }}>
      {children}
    </CartContext.Provider>
  );
};

export default CartProvider;
export const useCart = () => useContext(CartContext);
