import Add from "./Add";
import AdminView from "./AdminView";
import { useEffect,useState } from 'react';
import Edit from "./Edit";

function Dashboard(){

    const [productsData,setProdctsData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
            const response = await fetch('http://localhost:8080/getAllProducts');
            const jsonData = await response.json();
            setProdctsData(jsonData);
            } catch (error) {
            console.error('Error fetching data:', error);
            }
        };
    
        fetchData();
        }, []);


    const [selectedProduct, setSelectedProduct] = useState(null);
    const [add, setAdd] = useState(false);
    const [edit, setEdit] = useState(false);

    const handleEdit = (id) => {
        const [productsData] = productsData.filter(product => product.productId === id);
        setSelectedProduct(product);
        setEdit(true);
    }


    return(
        <>
            {!add && !edit && <AdminView 
                productsList={productsData} 
                handleEdit={handleEdit} 
                handleDelete={handleDelete}
            />}
            {add && <Add productsData={productsData} setProdctsData={setProdctsData} setAdd={setAdd}/>}
            {edit && <Edit productsData={productsData} setProdctsData={setProdctsData} selectedProduct={selectedProduct} setEdit={setEdit}/>}
        </>
    )
}

export default Dashboard;