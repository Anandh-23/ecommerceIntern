import Add from "./Add";
import AdminView from "./AdminView";
import { useEffect,useState } from 'react';
import Edit from "./Edit";
import { PersonPlusFill } from 'react-bootstrap-icons';

function Dashboard(){

    const [productsData,setProductsData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
            const response = await fetch('http://localhost:8080/getAllProducts');
            const jsonData = await response.json();
            setProductsData(jsonData);
            } catch (error) {
            console.error('Error fetching data:', error);
            }
        };
    
        fetchData();
        }, []);

    const [selectedProduct, setSelectedProduct] = useState(null);
    const [add, setAdd] = useState(false);
    const [edit, setEdit] = useState(false);

    const handleEdit = (id) => {
        const [products] = productsData.filter(products => products.productId === id);
        setSelectedProduct(products);
        setEdit(true);
    }

    const handleDelete = (id) => {
        
    }

    return(
        <>
            {!add && !edit && <AdminView 
                productsList={productsData} 
                handleEdit={handleEdit} 
                handleDelete={handleDelete}
            />}
            {!add && <PersonPlusFill style={{marginLeft:'65rem',marginTop:'-4rem'}} color="green" size={50} onClick={() => setAdd(true)}/>}
            {add && <Add add = {add} productsData={productsData} setProductsData={setProductsData} setAdd={setAdd}/>}
            {edit && <Edit productsData={productsData} setProductsData={setProductsData} selectedProduct={selectedProduct} setEdit={setEdit}/>}
        </>
    )
}

// export default setAdd;
export default Dashboard;