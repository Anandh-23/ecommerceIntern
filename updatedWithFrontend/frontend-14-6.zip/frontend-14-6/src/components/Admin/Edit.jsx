const Edit = () => {
    return(
        <>Edit</>
    )
}

export default Edit;