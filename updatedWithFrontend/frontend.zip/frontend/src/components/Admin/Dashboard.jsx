import AdminView from "./AdminView";
import { useEffect,useState } from 'react';

function Dashboard(){

    const [productsData,setProdctsData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
            const response = await fetch('http://localhost:8080/getAllProducts');
            const jsonData = await response.json();
            setProdctsData(jsonData);
            } catch (error) {
            console.error('Error fetching data:', error);
            }
        };
    
        fetchData();
        }, []);


    const [product, setProduct] = useState(productsData);
    const [selectedClient, setSelectedClient] = useState(null);
    const [add, setAdd] = useState(false);
    const [edit, setEdit] = useState(false);

    const handleEdit = (id) => {
        const [product] = product.filter(product => product.productid === id);
        setSelectedClient(product);
        setEdit(true);
    }


    return(
        <AdminView productsList={productsData}/>
        

    )
}

export default Dashboard;