import { useRef,useState } from 'react';
import { useNavigate } from "react-router-dom";
import './AuthForm.css';
const AuthForm = () =>{
    const nameRef = useRef();
    const mobileRef = useRef();
    const passwordRef = useRef();
    const [isLogin, setIsLogin] = useState(true);
    const navigate = useNavigate();
    const [customer, setCustomer] = useState();
    let role = "Customer";
    const switchAuthModeHandler = () => {
        setIsLogin((prevState)=>!prevState);
    }

    const submitHandler = async(e)=>{
        e.preventDefault();
        console.log("Submitted");
        // setCustomer({
        //     customerName:nameRef.current.value,
        //     mobileNumber:mobileRef.current.value,
        //     password:passwordRef.current.value
        // })
        const mobileNumber = mobileRef.current.value;
        const password = passwordRef.current.value;
        // console.log(password);
        
        if(nameRef.current.value === "Admin" || nameRef.current.value === "admin"){
            role = "Admin";
        }
        
        
        console.log(customer);
        // const response = await fetch("http://localhost:8080/customers/addCustomer",{
        //     method:'POST',
        //     headers:{
        //         'Content-Type':'application/json'
        //     },
        //     body:JSON.stringify(customer)
        // });

        const response1 = await fetch("http://localhost:8080/login",{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({ mobileNumber, password })
        });

        if(response1.ok){
            navigate("/auth");
        }
        else{
            navigate("/auth");
        }

        // localStorage.setItem("name",nameRef.current.value);

        // const response
    }

    return(
        <section className='auth'>
            <h2>{isLogin ? "Login" : "Sign Up"}</h2>
            <form onSubmit={submitHandler}>
                <div className='control'>
                    <label htmlFor="name">Name</label>
                    <input type="text" id="name" required ref={nameRef}/>
                </div>
                <div className='control'>
                    <label htmlFor="mobileNumber">Mobile Number</label>
                    <input type="text" id="mobileNumber" required ref={mobileRef}/>
                </div>
                <div className='control'>
                    <label htmlFor="password">Password</label>
                    <input type="text" id="password" required ref={passwordRef}/>
                </div>
                <div className='actions'>
                    <button type="submit" >{isLogin ? "Login" : "Create Account"}</button>
                    <button type="button" className='toggle' style={{outline:"none"}} onClick={switchAuthModeHandler}>{isLogin ? "Create new account" : "Login with existing account"}</button>
                </div>
            </form>
        </section>
    )
}

export default AuthForm;

// onClick={() => {
//     setCustomer({
//         // customerName:nameRef.current.value,
//         mobileNumber:mobileRef.current.value,
//         password:passwordRef.current.value,
//         role:role,
//         // balance:100
//     })
// }}