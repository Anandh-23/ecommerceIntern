import { createContext,useContext,useState } from "react";

export const CartContext = createContext();

const CartProvider = ({children}) => {
    const [cart, setCart] = useState({
        customerId: 1,
        products : []
    });

    const isCartEmpty = () => {
        return cart.products.length === 0;
    }

    const addToCart = async(product) => {
        if(isCartEmpty){
            console.log("Empty Cart");

            fetch("http://localhost:8080/cart/addToCart",{
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify(product),
            }).then((response) => response.json())
            .then((updatedCart) => {
                setCart(updatedCart);
                console.log("Cart updated:",updatedCart);
            })
            .catch((e)=>{
                console.error("Error:",e);
            })
        }

        else{
            const existingProductIndex = cart.products.findIndex(
                (item) => item.productId === product.productId
              );

              if(existingProductIndex !== -1) {
                // Product already exists, increase quantity by 1
                const updatedCart = { ...cart };
                updatedCart.products[existingProductIndex].quantity += 1;
                setCart(updatedCart);
                console.log("Cart updated:", updatedCart);
              } else {
                // Product doesn't exist, add it to the cart
                const updatedCart = { ...cart };
                updatedCart.products.push(product);
                setCart(updatedCart);
                console.log("Cart updated:", updatedCart);
              }
        }
    }



    return(
        <CartContext.Provider value = {{cart,addToCart}}>
            {children}
        </CartContext.Provider>
    )
}

export default CartProvider;
export const useCart = () => useContext(CartContext);