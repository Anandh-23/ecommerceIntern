import './NavBar.css';
import {Navbar,Nav, Container} from 'react-bootstrap';
const NavBar = () => {
    return(
    <div>
        <Navbar variant='dark' style={{background: '#024180'}} fixed='top'>
            <Container>
                <Navbar.Brand style={{color: 'rgb(248, 248, 96)',fontSize: '30px'}}>E-Commerce</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto">
                    <Nav.Link href="#home">Login</Nav.Link>
                    <Nav.Link href="#productAdd">Add Product</Nav.Link>
                    <Nav.Link href="/cart">Cart</Nav.Link>
                    <Nav.Link href="#products">My Orders</Nav.Link>
                    <Nav.Link href="#logout">Logout</Nav.Link>
                </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    </div>
    )
}

export default NavBar;