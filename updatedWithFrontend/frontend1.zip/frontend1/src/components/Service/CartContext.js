import { createContext,useContext,useState } from "react";

export const CartContext = createContext();

const CartProvider = ({children}) => {
    localStorage.setItem("customerId",7);
    const custId = localStorage.getItem("customerId");
    const [cart, setCart] = useState({
        customer: {
            customerId:custId
        },
        cartProducts:[]
    });

    const isCartEmpty = async() => {
        const response = await fetch(`http://localhost:8080/cart/customer/${custId}`);
        const jsonData = await response.json();
        console.log("JSON DATA");
        console.log(jsonData);
        setCart(jsonData);
        console.log("CART");
        console.log(cart);
        return cart.cartProducts.length === 0;
    };

    const addToCart = async(product) => {
        
        if(isCartEmpty()){
            console.log("Empty Cart");
            cart.cartProducts.push({
                product: {
                    productId: product.productId,
                },
                quantity : 1
            })
            const cartResponse = await fetch("http://localhost:8080/cart/addToCart",{
                method:'POST',
                headers:{
                    'Content-Type':'application/json'
                },
                body:JSON.stringify(cart)
            });
            if(cartResponse.ok){
                alert("Added");
            }
            else{
                console.log(cart);
                alert("Not Added");
            }
        }

        else{
            console.log("Something in Cart");
        }
    }



    return(
        <CartContext.Provider value = {{cart,addToCart}}>
            {children}
        </CartContext.Provider>
    )
}

export default CartProvider;
export const useCart = () => useContext(CartContext);