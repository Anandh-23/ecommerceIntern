import axios from "axios";
import { createContext, useState, useEffect } from "react";

export const UserContext = createContext();

export function UserContextProvider(children){
    const addCustomerurl = "http://localhost:8080/customers/addCustomer";
    const [customer, setCustomer] = useState();
    const postCustomer = async(url,body) =>{
        try{
            const {data} = await axios.post(url,body)
            console.log(data);
        }
        catch(e){
            console.log(e.response);
        }
    }

    useEffect(() => {
      if(customer){
        postCustomer(addCustomerurl,customer);
      }
    }, [customer])
    return(
        <UserContext.Provider value={{setCustomer}}>
            {children}
        </UserContext.Provider>
    )
    
}