import { useState, useEffect, useRef } from "react";

const Edit = ({ selectedProduct, setEdit, edit }) => {
  const id = selectedProduct.productId;
  const [name, setName] = useState(selectedProduct.productName);
  const [price, setPrice] = useState(selectedProduct.price);
  const [stock, setStock] = useState(selectedProduct.stock);
  const [category, setCategory] = useState(selectedProduct.category);
  const [url, setUrl] = useState(selectedProduct.url);
  const input = useRef(null);

  useEffect(() => {
    input.current.focus();
  }, [edit]);

  const handleUpdate = async (event) => {
    event.preventDefault();
    const updatedClient = {
      productId: id,
      productName: name,
      price: price,
      stock: stock,
      category: category,
      url: url,
    };

    const updateResponse = await fetch(`http://localhost:8080/products/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedClient),
    });

    if (updateResponse.ok) {
      alert("Updated Successfully");
    } else {
      alert("Update Product error");
    }
    setEdit(false);
  };

  return (
    <div style={{ width: "40%", marginTop: "5rem" }} className="container">
      <form>
        <center>
          <h3>Edit Product</h3>
        </center>
        <div>
          <label htmlFor="name">Name</label>
          <input
            id="name"
            type="text"
            ref={input}
            placeholder="Enter name"
            name="name"
            minLength="5"
            maxLength="20"
            value = {name}
            required
            onChange={(e) => setName(e.target.value)}
          ></input>
        </div>

        <div>
          <label htmlFor="price">Price</label>
          <input
            id="price"
            type="number"
            placeholder="Enter Price"
            name="price"
            value = {price}
            required
            onChange={(e) => setPrice(e.target.value)}
          ></input>
        </div>

        <div>
          <label htmlFor="stock">Stock</label>
          <input
            id="stock"
            type="number"
            placeholder="Enter Stock"
            name="stock"
            min="1"
            value = {stock}
            required
            onChange={(e) => setStock(e.target.value)}
          ></input>
        </div>

        <div>
          <label htmlFor="category">Category</label>
          <input
            id="category"
            type="text"
            placeholder="Enter Category"
            name="category"
            value = {category}
            required
            onChange={(e) => setCategory(e.target.value)}
          ></input>
        </div>

        <div>
          <label htmlFor="url">URL</label>
          <input
            id="url"
            type="url"
            placeholder="Enter Url"
            name="url"
            value = {url}
            required
            onChange={(e) => setUrl(e.target.value)}
          ></input>
        </div>

        <div className="center">
          <button
            className="btn btn-success"
            type="submit"
            onClick={handleUpdate}
          >
            Update
          </button>
          <button
            className="btn btn-danger"
            type="cancel"
            onClick={() => setEdit(false)}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default Edit;
