import './NavBar.css';
import {Navbar,Nav, Container} from 'react-bootstrap';
// import {useUser, UserContext } from '../Service/user-context';

const NavBar = () => {
    // const {isLoggedin,user} = useUser(UserContext);
    // isCustomer = user ? "" : "";

    return(
    <div>
        <Navbar variant='dark' style={{background: '#024180'}} fixed='top'>
            <Container>
                <Navbar.Brand style={{color: 'rgb(248, 248, 96)',fontSize: '30px'}}>E-Commerce</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto">
                    {<Nav.Link>Login</Nav.Link>}
                    {<Nav.Link>Add Product</Nav.Link>}
                    {<Nav.Link>Cart</Nav.Link>}
                    {<Nav.Link>My Orders</Nav.Link>}
                    {<Nav.Link>Logout</Nav.Link>}
                </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    </div>
    )
}

export default NavBar;