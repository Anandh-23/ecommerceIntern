import Add from "./Add";
import AdminView from "./AdminView";
import { useEffect, useState } from "react";
import Edit from "./Edit";
import { CardList } from "react-bootstrap-icons";

function Dashboard() {
  const [productsData, setProductsData] = useState([]);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [add, setAdd] = useState(false);
  const [edit, setEdit] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8080/getAllProducts");
        const jsonData = await response.json();
        setProductsData(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [add, edit]);

  const handleEdit = (id) => {
    const [products] = productsData.filter(
      (products) => products.productId === id
    );
    setSelectedProduct(products);
    setEdit(true);
  };

  const handleDelete = async(id) => {
    try{
      const response = await fetch(`http://localhost:8080/products/${id}`,{
        method: 'DELETE'
      })
      if(response.ok)
        alert("Deleted")
      else
        alert("Warning!!! It's in Customer's cart")
    }
    catch(e){
      alert("Delete Catch")
      console.log("Unable to Delete",e)
    }
    
  };

  return (
    <>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {!add && !edit && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginLeft: "-15rem",
            }}
          >
            <AdminView
              productsList={productsData}
              handleEdit={handleEdit}
              handleDelete={handleDelete}
            />
            <div style={{ marginLeft: "6rem" }}>
              <CardList
                style={{ color: "green", cursor: "pointer" }}
                size={50}
                onClick={() => setAdd(true)}
              />
            </div>
          </div>
        )}
        {add && (
          <Add
            add={add}
            setAdd={setAdd}
          />
        )}
        {edit && (
          <Edit
            selectedProduct={selectedProduct}
            setEdit={setEdit}
            edit = {edit}
          />
        )}
      </div>
    </>
  );
}

export default Dashboard;
