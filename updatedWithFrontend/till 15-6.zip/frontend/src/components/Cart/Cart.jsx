import {useState, useEffect} from 'react';
import {Card, Button} from 'react-bootstrap';

const Cart = () => {
    const [cartItems, setCartItems] = useState([]);
    localStorage.setItem("customerId",16)
    const custId = localStorage.getItem("customerId");

    useEffect(() => {
        const fetchCart = async () => {
            try {
              const response = await fetch(`http://localhost:8080/cart/customer/${custId}`);
              const jsonData = await response.json();
              console.log(jsonData);
              setCartItems(jsonData.cartProducts);
              console.log(cartItems);
              
            } catch (error) {
              console.error("Error fetching cart:", error);
            }
          };
        fetchCart();
      },[]);

  return (
    <div style={{ marginTop: "8rem" }} className="container">
        <div className='row'>
            {
                cartItems.map((item) => (
                    <div key = {item.cartProductId} className="col-lg-4 mb-4">
                        <Card>
                            <Card.Body>
                                <Card.Title>{item.product.productName}</Card.Title>
                                <Card.Text>Quantity  <button style={{marginLeft : '0.5rem'}}>+</button><span style={{paddingLeft : '0.75rem',paddingRight : '0.75rem'}}>{item.quantity}</span><button>-</button></Card.Text>
                                <Button>Remove</Button>
                            </Card.Body>
                        </Card>
                    </div>
                ))
            }
        </div>
        <center><Button variant = "success">Order Now</Button></center>
    </div>
  );
};

export default Cart;
