import { Route, Routes, Navigate } from "react-router-dom";
import AuthForm from "./components/Authentication/AuthForm";
import Layout from "./components/Layout/Layout";
import ViewProduct from "./components/Product/ViewProduct";
import Cart from "./components/Cart/Cart";
import CartProvider from "./components/Service/CartContext";
import UserContextProvider from "./components/Service/user-context";
import Dashboard from "./components/Admin/Dashboard";
import User from "./components/User";

function App() {
  return (
    <UserContextProvider>
      <CartProvider>
        <div>
          <Layout>
            <Routes>
              <Route path="/" element={<ViewProduct />} />
              <Route path="/auth" element={<AuthForm />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/admin" element={<Dashboard />} />
              <Route path="/user" element={<User/>} />
              <Route path="*" element={<Navigate replace to="/" />} />
            </Routes>
          </Layout>
        </div>
      </CartProvider>
    </UserContextProvider>
  );
}

export default App;
