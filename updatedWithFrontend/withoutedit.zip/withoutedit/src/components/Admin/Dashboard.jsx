import Add from "./Add";
import AdminView from "./AdminView";
import { useEffect, useState } from "react";
import Edit from "./Edit";
import { PersonPlusFill } from "react-bootstrap-icons";

function Dashboard() {
  const [productsData, setProductsData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8080/getAllProducts");
        const jsonData = await response.json();
        setProductsData(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [productsData]);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [add, setAdd] = useState(false);
  const [edit, setEdit] = useState(false);

  const handleEdit = (id) => {
    const [products] = productsData.filter(
      (products) => products.productId === id
    );
    setSelectedProduct(products);
    setEdit(true);
  };

  const handleDelete = (id) => {};

  return (
    <>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {!add && !edit && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginLeft: "-15rem",
            }}
          >
            <AdminView
              productsList={productsData}
              handleEdit={handleEdit}
              handleDelete={handleDelete}
            />
            <div style={{ marginLeft: "6rem" }}>
              <PersonPlusFill
                style={{ color: "green", cursor: "pointer" }}
                size={50}
                onClick={() => setAdd(true)}
              />
            </div>
          </div>
        )}
        {add && (
          <Add
            add={add}
            productsData={productsData}
            setProductsData={setProductsData}
            setAdd={setAdd}
          />
        )}
        {edit && (
          <Edit
            productsData={productsData}
            setProductsData={setProductsData}
            selectedProduct={selectedProduct}
            setEdit={setEdit}
          />
        )}
      </div>
    </>
  );
}

// export default setAdd;
export default Dashboard;
