function ProductList (){
    const response = fetch('http://localhost:8080/getAllProducts');
}