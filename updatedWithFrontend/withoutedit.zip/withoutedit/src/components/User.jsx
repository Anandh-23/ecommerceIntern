import {useState, useEffect} from 'react';

function User(){
    const [productsData,setProdctsData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
            const response = await fetch('http://localhost:8080/user');
            const jsonData = await response.json();
            setProdctsData(jsonData);
            } catch (error) {
            console.error('Error fetching data:', error);
            }
        };
    
        fetchData();
        }, []);
        // console.log(productsData)
    return(
        
        <p>{productsData}</p>
    )
}

export default User;